package com.amrita.jpl.cys21037.p1;

import java.util.Scanner;

/**
 * This class provides various mathematical functions.
 * @author M K Ganesh
 * @version 1.0
 */
public class Periodical {
    /**
     * Calculates the factorial of a given number.
     *
     * @param n the number for which factorial is calculated
     * @return the factorial of the given number
     */
    public static int fact(int n) {
        if (n == 0) {
            return 1;
        } else {
            return n * fact(n - 1);
        }
    }

    /**
     * Prints the Fibonacci series up to the specified number of terms.
     *
     * @param count the number of terms in the Fibonacci series
     */
    public static void fibo(int count) {
        int num1 = 0, num2 = 1, num3, i;
        System.out.print("The Fibonacci Series up to " + count + " terms is: " + num1 + ", " + num2);
        for (i = 2; i < count; ++i) {
            num3 = num1 + num2;
            System.out.print(" " + num3);
            num1 = num2;
            num2 = num3;
        }
        System.out.println();
    }

    /**
     * Calculates the sum of the first n natural numbers.
     *
     * @param n the number of terms to be summed
     * @return the sum of the first n natural numbers
     */
    public static int sum_n_no(int n) {
        int sum = 0;
        int i;
        for (i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }

    /**
     * Checks if a given number is prime and prints the result.
     *
     * @param n the number to be checked for primality
     * @return always returns 0
     */
    public static int prime_test(int n) {
        int i, count = 0;
        for (i = 2; i < n; i++) {
            if (n % i == 0) {
                count++;
                break;
            }
        }
        if (count == 0) {
            System.out.println("Given Number is: " + n);
            System.out.println("\nIt is a Prime Number.");
        } else {
            System.out.println("Given Number is: " + n);
            System.out.println("\nIt is not a Prime Number.");
        }
        return 0;
    }

    /**
     * The main method that provides a menu to choose different mathematical functions.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        System.out.println("1. Factorial");
        System.out.println("2. Fibonacci");
        System.out.println("3. Sum of N numbers");
        System.out.println("4. Prime Test");
        System.out.print("Enter your Choice: ");
        choice = scanner.nextInt();

        if (choice == 1) {
            int n;
            System.out.print("Enter a number for Factorial: ");
            n = scanner.nextInt();
            System.out.println("Factorial of the given number " + n + " is: " + fact(n));
        } else if (choice == 2) {
            int count;
            System.out.print("Enter the number of terms for Fibonacci: ");
            count = scanner.nextInt();
            fibo(count);
        } else if (choice == 3) {
            int n;
            System.out.print("Enter the number to calculate the sum: ");
            n = scanner.nextInt();
            System.out.println("Sum of the first " + n + " numbers is: " + sum_n_no(n));
        } else {
            int n;
            System.out.print("Enter a number to check: ");
            n = scanner.nextInt();
            prime_test(n);
        }
    }
}
