package com.amrita.jpl.cys21037.ex;

/**
 * This class represents a vehicle.
 *@autrhor M K Ganesh
 * @version 1.0
 *
 */
class Vehicle {
    protected boolean run_status;

    /**
     * Initializes a Vehicle object with the run_status set to false.
     */
    public Vehicle() {
        run_status = false;
    }

    /**
     * Starts the vehicle.
     */
    public void start() {
        run_status = true;
        System.out.println("[Vehicle] started.");
    }

    /**
     * Stops the vehicle.
     */
    public void stop() {
        run_status = false;
        System.out.println("[Vehicle] stopped.");
    }
}

/**
 * This class represents a car, which is a type of vehicle.
 */
class Car extends Vehicle {
    private String model;
    private int year;
    private int numWheels;

    /**
     * Initializes a Car object with the given model, year, and number of wheels.
     *
     * @param model      the model of the car
     * @param year       the year of the car
     * @param numWheels  the number of wheels on the car
     */
    public Car(String model, int year, int numWheels) {
        this.model = model;
        this.year = year;
        this.numWheels = numWheels;
        System.out.println("Car Instantiated with Parameter " + model + ", " + year + ", " + numWheels);
    }

    /**
     * Drives the car in the specified gear position.
     *
     * @param gearPosition the gear position to drive the car in
     */
    public void drive(int gearPosition) {
        if (run_status) {
            System.out.println("Driving the car in gear position: " + gearPosition);
        } else {
            System.out.println("Error: The car is not running.");
        }
    }
}

/**
 * This class represents a bike, which is a type of vehicle.
 */
class Bike extends Vehicle {
    private String brand;
    private int year;
    private int numGears;

    /**
     * Initializes a Bike object with the given brand, year, and number of gears.
     *
     * @param brand     the brand of the bike
     * @param year      the year of the bike
     * @param numGears  the number of gears on the bike
     */
    public Bike(String brand, int year, int numGears) {
        this.brand = brand;
        this.year = year;
        this.numGears = numGears;
        System.out.println("Bike Instantiated with Parameter " + brand + ", " + year + ", " + numGears);
    }

    /**
     * Pedals the bike at the specified pedal speed.
     *
     * @param pedalSpeed the speed at which the bike is pedaled
     */
    public void pedal(int pedalSpeed) {
        if (run_status) {
            System.out.println("Pedaling the bike at speed: " + pedalSpeed);
        } else {
            System.out.println("Error: The bike is not running.");
        }
    }
}

/**
 * This class contains the main method and serves as the entry point for the program.
 */
public class Main {
    public static void main(String[] args) {
        // Create a Car object and test its functionalities
        Car car = new Car("Jaguar XF", 2022, 4);
        car.start();
        car.drive(3);
        car.stop();

        // Create a Bike object and test its functionalities
        Bike bike = new Bike("Giant", 2021, 18);
        bike.start();
        bike.pedal(10);
        bike.stop();
    }
}
