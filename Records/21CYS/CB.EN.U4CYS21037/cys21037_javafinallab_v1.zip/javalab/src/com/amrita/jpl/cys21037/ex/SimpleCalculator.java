package com.amrita.jpl.cys21037.ex;

import java.util.Scanner;

/**
 * This interface represents a calculator with basic arithmetic operations.
 * @author M K Ganesh
 * @version 1.0
 */
interface Calculator {
    /**
     * Adds two numbers.
     *
     * @param a the first number
     * @param b the second number
     * @return the sum of the two numbers
     */
    double add(double a, double b);

    /**
     * Subtracts the second number from the first number.
     *
     * @param a the first number
     * @param b the second number
     * @return the result of subtracting the second number from the first number
     */
    double subtract(double a, double b);

    /**
     * Multiplies two numbers.
     *
     * @param a the first number
     * @param b the second number
     * @return the product of the two numbers
     */
    double multiply(double a, double b);

    /**
     * Divides the first number by the second number.
     *
     * @param a the numerator
     * @param b the denominator
     * @return the result of dividing the first number by the second number
     * @throws ArithmeticException if the denominator is zero
     */
    double divide(double a, double b) throws ArithmeticException;
}

/**
 * This class implements the Calculator interface and provides basic arithmetic operations.
 */
class BasicCalculator implements Calculator {
    @Override
    public double add(double a, double b) {
        return a + b;
    }

    @Override
    public double subtract(double a, double b) {
        return a - b;
    }

    @Override
    public double multiply(double a, double b) {
        return a * b;
    }

    @Override
    public double divide(double a, double b) throws ArithmeticException {
        if (b == 0) {
            throw new ArithmeticException("Division by zero error!");
        }
        return a / b;
    }
}

/**
 * This class provides a simple calculator application that uses the BasicCalculator class.
 */
public class SimpleCalculator {
    public static void main(String[] args) {
        // Create an instance of BasicCalculator
        Calculator calculator = new BasicCalculator();

        // Read two numbers from the user
        Scanner scanner = new Scanner(System.in);
        double num1 = scanner.nextDouble();
        double num2 = scanner.nextDouble();

        // Perform arithmetic operations
        double addition = calculator.add(num1, num2);
        double subtraction = calculator.subtract(num1, num2);
        double multiplication = calculator.multiply(num1, num2);
        double division;
        try {
            division = calculator.divide(num1, num2);
            System.out.println("Addition: " + addition);
            System.out.println("Subtraction: " + subtraction);
            System.out.println("Multiplication: " + multiplication);
            System.out.println("Division: " + division);
        } catch (ArithmeticException e) {
            System.out.println("Addition: " + addition);
            System.out.println("Subtraction: " + subtraction);
            System.out.println("Multiplication: " + multiplication);
            System.out.println("Division by zero error!");
            System.out.println("Division: -1.0");
        }
    }
}
